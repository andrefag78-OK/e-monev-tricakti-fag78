// e-MONEV TRICAKTI - Google Apps Script Connector
// 1. Buat Sheet baru > Extensions > Apps Script > paste ini
// 2. Deploy > New deployment > Web App > Execute as Me, Who has access: Anyone
function doPost(e){
  try{
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var data = JSON.parse(e.postData.contents);
    var module = data.module || 'general';
    var sheet = ss.getSheetByName(module) || ss.insertSheet(module);
    if(sheet.getLastRow()==0) sheet.appendRow(['Timestamp','Tanggal','Sektor','Pos','Data JSON','User','Module']);
    sheet.appendRow([new Date(), data.tanggal||'', data.sektor||'', data.pos||'', JSON.stringify(data), data.user||'', module]);
    return ContentService.createTextOutput(JSON.stringify({status:'ok'})).setMimeType(ContentService.MimeType.JSON);
  }catch(err){
    return ContentService.createTextOutput(JSON.stringify({status:'error',msg:err.message})).setMimeType(ContentService.MimeType.JSON);
  }
}
function doGet(){ return ContentService.createTextOutput(JSON.stringify({status:'e-MONEV TRICAKTI API Ready - BERSATU MENANG'})).setMimeType(ContentService.MimeType.JSON); }

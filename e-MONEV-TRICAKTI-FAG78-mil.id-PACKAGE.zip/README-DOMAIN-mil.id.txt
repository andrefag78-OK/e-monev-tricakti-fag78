# Deploy ke e-monev-tricakti-fag78.mil.id - Cloudflare Pages

DOMAIN TARGET: e-monev-tricakti-fag78.mil.id

1. Extract ZIP ini
2. Buka https://dash.cloudflare.com -> Workers & Pages -> Create -> Upload assets
3. Upload semua file (index.html, install.html, QR-CETAK-A4-27POS.html, manifest.json, sw.js, resource_logo.png, _headers, _redirects)
4. Deploy -> dapat https://e-monev-tricakti-fag78.pages.dev
5. Tab Custom domains -> Set up custom domain -> ketik e-monev-tricakti-fag78.mil.id -> Activate
6. Jika domain mil.id belum di Cloudflare: Add site -> masukkan mil.id -> ganti nameserver di registrar .mil.id dengan nameserver Cloudflare
7. SSL otomatis

Lihat file PANDUAN-CLOUDFLARE-DOMAIN-mil.id.html untuk panduan lengkap bergambar.

Jika .mil.id belum ada, pakai dulu .pages.dev sambil urus pendaftaran .mil.id via PANDI (butuh surat satuan).

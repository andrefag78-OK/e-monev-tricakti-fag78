# e-MONEV OPERASIONAL SATLAP TRICAKTI (FAG) - BERSATU MENANG
Paket ZIP siap upload.

## ISI PAKET
- index.html / e-MONEV-SATLAP-TRICAKTI-FAG.html : Aplikasi utama (PWA, offline-ready)
- install.html : Halaman installer dengan QR + tombol Install Otomatis tanpa ADB
- QR-CETAK-A4-27POS.html : Lembar A4 dengan 27 QR Pos + 8 RBB, siap cetak tempel di dinding Pos
- manifest.json : Untuk PWA
- sw.js : Service worker offline
- resource_logo.png : Logo resmi
- Code.gs : Sample Google Apps Script untuk sync ke Google Sheets (Excel berbasis AppScript modern)
- README.md

## CARA DEPLOY (FREE, Tanpa Kartu)
### OPSI 1 - Vercel (1 menit)
1. Buka vercel.com -> Add New -> Project -> Upload folder ini (drag & drop)
2. Deploy -> Dapat URL https://xxx.vercel.app
3. Buka URL di HP -> install.html akan auto QR

### OPSI 2 - Netlify Drop
https://app.netlify.com/drop -> drag folder -> online

### OPSI 3 - cPanel / VPS / Niagahoster
Upload semua file ke public_html/ via File Manager -> Aktifkan SSL -> akses domain

### OPSI 4 - Firebase
firebase init hosting -> firebase deploy

## KONEKSI GOOGLE SHEETS (Excel AppScript Modern)
1. Buat Google Sheet baru
2. Extensions -> Apps Script -> paste Code.gs
3. Deploy -> New Deployment -> Web App -> Execute as Me, Anyone with link
4. Copy URL Web App -> paste di aplikasi menu Pengaturan -> AppScript Sync URL -> Test Koneksi
5. Semua input petugas otomatis masuk ke Sheet per modul (tab = nama modul)

## INSTALL DI HP PETUGAS (TANPA ADB)
- Scan QR di Pos (install.html) atau QR-CETAK-A4
- Chrome Android: Klik Install Otomatis -> Add to Home Screen
- iPhone: Share -> Add to Home Screen
- APK: Buka pwabuilder.com -> Masukkan URL Vercel Anda -> Package for Android -> Download APK -> share ke grup WA Pos

## LOGIN DEFAULT
Admin Utama: FirstAndreGitrias / Tricakti2026! (bisa diedit nama di Pengaturan)
Operator Kosatlap & petugas lain dibuat di menu Users & ID Card

## FITUR
- 10 modul pendataan sesuai file WA Grup, Drone, RBB, Tinara, Gakkum, Siber
- Dropdown editable hanya Admin & Operator Kosatlap
- Upload docx/xlsx/pptx/pdf/foto/video (base64 localStorage, bisa sync ke Sheets)
- Date range, export CSV, ID Card QR, QR Scanner, Chat interaktif, Pemetaan Leaflet, Riset AI (Risk Matrix, SWOT, PESTEL, Network Analysis, Balanced Scorecard, Quantum Leap)
- BPS Babel & PT Timah news integration

Semua data kosong, hanya struktur siap isi petugas.

BERSATU - MENANG
